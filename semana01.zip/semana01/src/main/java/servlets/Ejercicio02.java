package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio02
 */
@WebServlet("/servletregistro")
public class Ejercicio02 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ejercicio02() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String nombre = request.getParameter("campoNombre");
		String apellido = request.getParameter("campoApellido");
		String carrera = request.getParameter("campoCarrera");
		String interes[] = request.getParameterValues("checkInteres");
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<ul>");
		out.print("<li>El nombre ingresado es:" + nombre + "</li>");
		out.print("<li>El apellido ingresado es:" + apellido + "</li>");
		out.print("<li>La carrera ingresado es:" + carrera + "</li>");
		
		for(int i = 0; i < interes.length; i++){
			out.print("<li>Interes seleccionado:" + interes[i] + "</li>");
		}
		out.print("</ul>");
		out.close();
	}

}
